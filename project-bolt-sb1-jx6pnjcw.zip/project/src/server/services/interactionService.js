import { query } from '../config/db.js';
import { createNotification } from './notificationService.js';

export const addInteraction = async (userId, postId, type, content = null) => {
  let result;
  
  if (type === 'comment') {
    result = await query(
      'INSERT INTO comments (post_id, user_id, content) VALUES ($1, $2, $3) RETURNING *',
      [postId, userId, content]
    );
  } else if (type === 'like') {
    result = await query(
      'INSERT INTO likes (post_id, user_id) VALUES ($1, $2) RETURNING *',
      [postId, userId]
    );
  }
  
  const postOwner = await query(
    'SELECT user_id FROM posts WHERE id = $1',
    [postId]
  );
  
  if (postOwner.rows[0]) {
    await createNotification(
      postOwner.rows[0].user_id,
      userId,
      type,
      `${type}d your post`
    );
  }
  
  return result.rows[0];
};