import { query } from '../config/db.js';

export const createNotification = async (recipientId, senderId, type, content) => {
  const result = await query(
    'INSERT INTO notifications (recipient_id, sender_id, type, content) VALUES ($1, $2, $3, $4) RETURNING *',
    [recipientId, senderId, type, content]
  );
  return result.rows[0];
};

export const getUserNotifications = async (userId) => {
  const result = await query(
    `SELECT n.*, u.username, u.full_name
     FROM notifications n
     LEFT JOIN users u ON n.sender_id = u.id
     WHERE n.recipient_id = $1
     ORDER BY n.created_at DESC`,
    [userId]
  );
  return result.rows;
};