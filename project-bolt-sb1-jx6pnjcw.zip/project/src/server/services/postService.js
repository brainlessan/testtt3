import { query } from '../config/db.js';

export const createPost = async (userId, content) => {
  const result = await query(
    'INSERT INTO posts (user_id, content) VALUES ($1, $2) RETURNING *',
    [userId, content]
  );
  return result.rows[0];
};

export const getPosts = async (page = 1, limit = 10) => {
  const offset = (page - 1) * limit;
  
  const posts = await query(
    `SELECT p.*, u.username, u.full_name
     FROM posts p
     JOIN users u ON p.user_id = u.id
     ORDER BY p.created_at DESC
     LIMIT $1 OFFSET $2`,
    [limit, offset]
  );
  
  const count = await query('SELECT COUNT(*) FROM posts');
  
  return {
    posts: posts.rows,
    totalPages: Math.ceil(count.rows[0].count / limit),
    currentPage: parseInt(page)
  };
};