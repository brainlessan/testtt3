export const validateRegistration = (req, res, next) => {
  const { email, password, username, fullName } = req.body;
  
  if (!email || !password || !username || !fullName) {
    return res.status(400).json({ error: 'All fields are required' });
  }
  
  if (password.length < 6) {
    return res.status(400).json({ error: 'Password must be at least 6 characters' });
  }
  
  next();
};

export const validatePost = (req, res, next) => {
  const { content } = req.body;
  
  if (!content || content.trim().length === 0) {
    return res.status(400).json({ error: 'Content is required' });
  }
  
  if (content.length > 500) {
    return res.status(400).json({ error: 'Content must be less than 500 characters' });
  }
  
  next();
};