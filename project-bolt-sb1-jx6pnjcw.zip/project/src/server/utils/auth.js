import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { query } from '../config/db.js';

export const generateToken = (userId) => {
  return jwt.sign({ id: userId }, process.env.JWT_SECRET, { expiresIn: '7d' });
};

export const createUser = async (email, password, username, fullName) => {
  const hashedPassword = await bcrypt.hash(password, 10);
  
  const userResult = await query(
    'INSERT INTO users (email, password_hash, username, full_name) VALUES ($1, $2, $3, $4) RETURNING *',
    [email, hashedPassword, username, fullName]
  );
  
  const user = userResult.rows[0];
  
  await query(
    'INSERT INTO user_settings (user_id) VALUES ($1)',
    [user.id]
  );
  
  return { user, token: generateToken(user.id) };
};