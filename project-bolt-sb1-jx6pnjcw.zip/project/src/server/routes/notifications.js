import express from 'express';
import { query } from '../config/db.js';

const router = express.Router();

// Get user notifications
router.get('/', async (req, res) => {
  const userId = req.user.id;

  try {
    const { rows } = await query(
      `SELECT n.*, u.username, u.full_name
       FROM notifications n
       LEFT JOIN users u ON n.sender_id = u.id
       WHERE n.recipient_id = $1
       ORDER BY n.created_at DESC`,
      [userId]
    );
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Mark notification as read
router.put('/:notificationId/read', async (req, res) => {
  try {
    const { rows } = await query(
      'UPDATE notifications SET read = true WHERE id = $1 AND recipient_id = $2 RETURNING *',
      [req.params.notificationId, req.user.id]
    );
    res.json(rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export { router as notificationsRouter };