import express from 'express';
import { query } from '../config/db.js';

const router = express.Router();

// Create news post
router.post('/', async (req, res) => {
  const { content } = req.body;
  const userId = req.user.id;

  try {
    const { rows } = await query(
      'INSERT INTO posts (user_id, content) VALUES ($1, $2) RETURNING *',
      [userId, content]
    );
    res.status(201).json(rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get news feed with pagination
router.get('/', async (req, res) => {
  const { page = 1, limit = 10 } = req.query;
  const offset = (page - 1) * limit;

  try {
    const { rows: posts } = await query(
      `SELECT p.*, u.username, u.full_name
       FROM posts p
       JOIN users u ON p.user_id = u.id
       ORDER BY p.created_at DESC
       LIMIT $1 OFFSET $2`,
      [limit, offset]
    );

    const { rows: [{ count }] } = await query('SELECT COUNT(*) FROM posts');

    res.json({
      posts,
      totalPages: Math.ceil(count / limit),
      currentPage: parseInt(page)
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export { router as newsRouter };