import express from 'express';
import { query } from '../config/db.js';

const router = express.Router();

// Get user settings
router.get('/', async (req, res) => {
  const userId = req.user.id;

  try {
    const { rows: [settings] } = await query(
      'SELECT * FROM user_settings WHERE user_id = $1',
      [userId]
    );
    res.json(settings);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update user settings
router.put('/', async (req, res) => {
  const { notifications_enabled, language, theme } = req.body;
  const userId = req.user.id;

  try {
    const { rows: [settings] } = await query(
      `INSERT INTO user_settings (user_id, notifications_enabled, language, theme)
       VALUES ($1, $2, $3, $4)
       ON CONFLICT (user_id) DO UPDATE
       SET notifications_enabled = $2, language = $3, theme = $4, updated_at = CURRENT_TIMESTAMP
       RETURNING *`,
      [userId, notifications_enabled, language, theme]
    );
    res.json(settings);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export { router as settingsRouter };