import express from 'express';
import { query } from '../config/db.js';

const router = express.Router();

// Get user bookmarks
router.get('/', async (req, res) => {
  const userId = req.user.id;

  try {
    const { rows } = await query(
      `SELECT b.*, p.*, u.username, u.full_name
       FROM bookmarks b
       JOIN posts p ON b.post_id = p.id
       JOIN users u ON p.user_id = u.id
       WHERE b.user_id = $1
       ORDER BY b.created_at DESC`,
      [userId]
    );
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Add bookmark
router.post('/', async (req, res) => {
  const { postId } = req.body;
  const userId = req.user.id;

  try {
    const { rows } = await query(
      'INSERT INTO bookmarks (user_id, post_id) VALUES ($1, $2) RETURNING *',
      [userId, postId]
    );
    res.status(201).json(rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Remove bookmark
router.delete('/:postId', async (req, res) => {
  try {
    await query(
      'DELETE FROM bookmarks WHERE post_id = $1 AND user_id = $2',
      [req.params.postId, req.user.id]
    );
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export { router as bookmarksRouter };