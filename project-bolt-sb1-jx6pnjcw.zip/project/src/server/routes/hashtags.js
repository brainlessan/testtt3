import express from 'express';
import { query } from '../config/db.js';

const router = express.Router();

// Get trending hashtags
router.get('/', async (req, res) => {
  try {
    const { rows } = await query(
      'SELECT * FROM hashtags ORDER BY post_count DESC LIMIT 10'
    );
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export { router as hashtagRouter };