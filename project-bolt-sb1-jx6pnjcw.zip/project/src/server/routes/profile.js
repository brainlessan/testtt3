import express from 'express';
import { query } from '../config/db.js';

const router = express.Router();

// Get user profile
router.get('/:userId', async (req, res) => {
  try {
    const { rows: [user] } = await query(
      `SELECT u.id, u.username, u.full_name, u.created_at,
              (SELECT json_agg(p.*) FROM posts p WHERE p.user_id = u.id) as posts
       FROM users u
       WHERE u.id = $1`,
      [req.params.userId]
    );
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update user profile
router.put('/', async (req, res) => {
  const { full_name, username } = req.body;
  const userId = req.user.id;

  try {
    const { rows: [user] } = await query(
      'UPDATE users SET full_name = $1, username = $2 WHERE id = $3 RETURNING id, username, full_name',
      [full_name, username, userId]
    );
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export { router as profileRouter };