import express from 'express';
import { query } from '../config/db.js';
import { createNotification } from '../utils/notifications.js';

const router = express.Router();

// Add interaction (like or comment)
router.post('/', async (req, res) => {
  const { postId, type, content } = req.body;
  const userId = req.user.id;

  try {
    let result;
    
    if (type === 'comment') {
      result = await query(
        'INSERT INTO comments (post_id, user_id, content) VALUES ($1, $2, $3) RETURNING *',
        [postId, userId, content]
      );
      
      // Get post owner for notification
      const postOwner = await query(
        'SELECT user_id FROM posts WHERE id = $1',
        [postId]
      );
      
      if (postOwner.rows[0]) {
        await createNotification(
          postOwner.rows[0].user_id,
          userId,
          'comment',
          'commented on your post'
        );
      }
    } else if (type === 'like') {
      result = await query(
        'INSERT INTO likes (post_id, user_id) VALUES ($1, $2) RETURNING *',
        [postId, userId]
      );
      
      const postOwner = await query(
        'SELECT user_id FROM posts WHERE id = $1',
        [postId]
      );
      
      if (postOwner.rows[0]) {
        await createNotification(
          postOwner.rows[0].user_id,
          userId,
          'like',
          'liked your post'
        );
      }
    }

    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export { router as interactionRouter };