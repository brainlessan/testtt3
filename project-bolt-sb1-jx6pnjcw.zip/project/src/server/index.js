import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { newsRouter } from './routes/news.js';
import { hashtagRouter } from './routes/hashtags.js';
import { interactionRouter } from './routes/interactions.js';
import { profileRouter } from './routes/profile.js';
import { notificationsRouter } from './routes/notifications.js';
import { bookmarksRouter } from './routes/bookmarks.js';
import { settingsRouter } from './routes/settings.js';
import { authRouter } from './routes/auth.js';
import { authenticateToken } from './middleware/auth.js';
import { errorHandler } from './middleware/errorHandler.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Public routes
app.use('/api/auth', authRouter);

// Protected routes
app.use('/api/news', authenticateToken, newsRouter);
app.use('/api/hashtags', authenticateToken, hashtagRouter);
app.use('/api/interact', authenticateToken, interactionRouter);
app.use('/api/profile', authenticateToken, profileRouter);
app.use('/api/notifications', authenticateToken, notificationsRouter);
app.use('/api/bookmarks', authenticateToken, bookmarksRouter);
app.use('/api/settings', authenticateToken, settingsRouter);

// Error handling
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});