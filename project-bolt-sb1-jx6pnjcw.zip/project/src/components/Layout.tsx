import React from 'react';
import Sidebar from './Sidebar';
import NewsFeed from './NewsFeed';
import TrendingTags from './TrendingTags';

const Layout = () => {
  return (
    <div className="container mx-auto flex flex-col md:flex-row min-h-screen">
      {/* Left Sidebar */}
      <div className="w-full md:w-1/4 p-4 md:sticky md:top-0 md:h-screen">
        <Sidebar />
      </div>
      
      {/* Main Content */}
      <div className="w-full md:w-2/4 border-x border-dark-700 p-4">
        <NewsFeed />
      </div>
      
      {/* Right Sidebar - Hashtags */}
      <div className="w-full md:w-1/4 p-4 md:sticky md:top-0 md:h-screen">
        <TrendingTags />
      </div>
    </div>
  );
};

export default Layout;