import React from 'react';
import { Home, Bell, Bookmark, User, Settings } from 'lucide-react';
import { Link } from 'react-router-dom';

const Sidebar = () => {
  const menuItems = [
    { icon: Home, label: 'Ana Sayfa', path: '/' },
    { icon: Bell, label: 'Bildirimler', path: '/notifications' },
    { icon: Bookmark, label: 'Kaydedilenler', path: '/bookmarks' },
    { icon: User, label: 'Profil', path: '/profile' },
    { icon: Settings, label: 'Ayarlar', path: '/settings' },
  ];

  return (
    <nav className="bg-dark-800 rounded-xl p-4">
      <ul className="space-y-2">
        {menuItems.map((item) => (
          <li key={item.path}>
            <Link
              to={item.path}
              className="flex items-center space-x-3 p-3 rounded-lg hover:bg-dark-700 hover:text-pastel-green transition-colors"
            >
              <item.icon className="w-6 h-6" />
              <span className="text-lg">{item.label}</span>
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  );
};

export default Sidebar;