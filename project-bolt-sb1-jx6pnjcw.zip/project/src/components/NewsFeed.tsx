import React from 'react';

const NewsFeed = () => {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold mb-6 text-pastel-green">Haber Akışı</h1>
      <div className="bg-dark-800 rounded-xl p-4 hover:border-pastel-green-dark hover:border transition-colors">
        <p className="text-gray-400">Henüz haber yok</p>
      </div>
    </div>
  );
};

export default NewsFeed;