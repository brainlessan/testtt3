import React from 'react';
import { Hash } from 'lucide-react';

const TrendingTags = () => {
  return (
    <div className="bg-dark-800 rounded-xl p-4">
      <h2 className="text-xl font-bold mb-4 text-pastel-green">Gündem</h2>
      <div className="space-y-3">
        {/* Hashtags will be populated from the backend */}
        <div className="flex items-center space-x-2 p-2 rounded-lg hover:bg-dark-700 hover:text-pastel-green transition-colors cursor-pointer">
          <Hash className="w-4 h-4" />
          <span>Henüz hashtag yok</span>
        </div>
      </div>
    </div>
  );
};

export default TrendingTags;