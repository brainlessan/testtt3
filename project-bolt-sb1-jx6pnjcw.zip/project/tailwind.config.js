/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        pastel: {
          green: '#98D8B6',
          'green-light': '#B5E4CA',
          'green-dark': '#7AC7A3'
        },
        dark: {
          900: '#121212',
          800: '#1E1E1E',
          700: '#2D2D2D'
        }
      }
    },
  },
  plugins: [],
  darkMode: 'class'
};